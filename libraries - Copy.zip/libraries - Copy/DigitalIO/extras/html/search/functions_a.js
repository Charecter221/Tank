var searchData=
[
  ['send',['send',['../class_soft_s_p_i.html#aec803c1e30f66ccfdf2ca885964e49f1',1,'SoftSPI']]],
  ['softi2cmaster',['SoftI2cMaster',['../group__soft_i2_c.html#ga7204e8a90254de24c0a0548b36ffe9a3',1,'SoftI2cMaster']]],
  ['start',['start',['../class_i2c_master_base.html#ac2e8be9d2809d31b0e456860ef357345',1,'I2cMasterBase::start()'],['../group__soft_i2_c.html#ga8ee650a6348bd7472c6ac6fb5c5265f5',1,'SoftI2cMaster::start()'],['../class_fast_i2c_master.html#ad64911a142973667a094b3ce051a5412',1,'FastI2cMaster::start()']]],
  ['stop',['stop',['../class_i2c_master_base.html#a8cbf416c6bbf9135bd5f0331ff1951d2',1,'I2cMasterBase::stop()'],['../group__soft_i2_c.html#gad8f52e1cbf15894472881afe439afa02',1,'SoftI2cMaster::stop()'],['../class_fast_i2c_master.html#a176dbc10bf47c581a5dfe042bfc430a3',1,'FastI2cMaster::stop()']]]
];
