var searchData=
[
  ['state_5frep_5fstart',['STATE_REP_START',['../group__soft_i2_c.html#ga950c0757df97cfc0a1f7fddaf21fd2a0',1,'SoftI2cMaster.h']]],
  ['state_5frx_5faddr_5fnack',['STATE_RX_ADDR_NACK',['../group__soft_i2_c.html#gaa42d42b48050ecdfb2111b669d892bb1',1,'SoftI2cMaster.h']]],
  ['state_5frx_5fdata',['STATE_RX_DATA',['../group__soft_i2_c.html#gad2cd52a768c24fa4e2ecf788835db429',1,'SoftI2cMaster.h']]],
  ['state_5fstop',['STATE_STOP',['../group__soft_i2_c.html#ga6303d577c073ad6b8c3350d96223c426',1,'SoftI2cMaster.h']]],
  ['state_5ftx_5faddr_5fnack',['STATE_TX_ADDR_NACK',['../group__soft_i2_c.html#gab17e0ed11b1eacfc8ceb714d9497f1db',1,'SoftI2cMaster.h']]],
  ['state_5ftx_5fdata',['STATE_TX_DATA',['../group__soft_i2_c.html#ga7f1b7aae9c4b0db47d08e603ed3dbd22',1,'SoftI2cMaster.h']]],
  ['state_5ftx_5fdata_5fnack',['STATE_TX_DATA_NACK',['../group__soft_i2_c.html#ga58292e5be793935a299a1f9738039f92',1,'SoftI2cMaster.h']]]
];
