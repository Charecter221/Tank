# ArduinoLearningBoard-Lib
Arduino Learning Board Library and Examples (for Arduino IDE)

Created for the Arduino Learning Board project and edited to
be able to be included in the Arduino IDE Library Manager

Visit http://www.ArduinoLearningBoard.com for more info
