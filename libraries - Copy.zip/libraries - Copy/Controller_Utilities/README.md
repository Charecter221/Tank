# Controller Utilities Library
[![arduino-library-badge](https://www.ardu-badge.com/badge/Controller%20Utilities.svg?)](https://www.ardu-badge.com/Controller%20Utilities) [![Build Status](https://github.com/dmadison/CtrlUtil/workflows/build/badge.svg?branch=master)](https://github.com/dmadison/CtrlUtil/actions?query=workflow%3Abuild)

This library contains a number of useful functions for developing custom game controllers with Arduino.

## License

This library is licensed under the terms of the [MIT license](https://opensource.org/licenses/MIT). See the [LICENSE](LICENSE) file for more information.
